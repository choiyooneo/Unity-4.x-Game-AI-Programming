using UnityEngine;
using System.Collections;
using Behave.Runtime;

public class AlienController : AgentAI, IAgent
{
    //My Behavior tree
    Behave.Runtime.Tree mTree;

    // Use this for initialization
    protected override IEnumerator Initialise()
    {
        //100% health
        health = 100;
        moveSpeed = 1.5f;
        attackRange = 3.0f;
        damage = 10.0f;
        elapsedAttackRate = 0.0f;
        attackRate = 3.0f;
        bDead = false;
        curTargetObject = null;

        //Initialise the Robots_and_Aliens_AgentAI behavior tree
        mTree = BLAgentBehaveLibrary.InstantiateTree(BLAgentBehaveLibrary.TreeType.Robots_and_Aliens_AgentAI, this);

        //Update the behavior tree tick according to the frequency specified
        while (Application.isPlaying && mTree != null)
        {
            AgentUpdate();
            yield return new WaitForSeconds(1.0f / mTree.Frequency);
        }
    }

    // Update is called once per frame
    void Update()
    {
        //Check the actions
        //Go straight to the base
        if (lastActionType == BLAgentBehaveLibrary.ActionType.FindTheBase)
        {
            transform.Translate(new Vector3(0, 0, moveSpeed * Time.deltaTime));
        }
        //If attacking the land Unit, then perform attack action in every updates as behaviors tree doesn't call every update due to performance
        else if (lastActionType == BLAgentBehaveLibrary.ActionType.AttackLandUnit)
        {
            elapsedAttackRate += Time.deltaTime;

            //Reduce the health of the hit agent
            if (elapsedAttackRate > attackRate)
            {
                elapsedAttackRate = 0.0f;
                if (curTargetObject != null)
                    curTargetObject.SendMessage("ApplyDamage", damage, SendMessageOptions.DontRequireReceiver);
            }
        }
        else if (lastActionType == BLAgentBehaveLibrary.ActionType.AttackTheBase)
        {
            elapsedAttackRate += Time.deltaTime;

            //Reduce the health of the hit agent
            if (elapsedAttackRate > attackRate)
            {
                elapsedAttackRate = 0.0f;
                if (AlienBase != null)
                    AlienBase.SendMessage("ApplyDamage", damage, SendMessageOptions.DontRequireReceiver);
            }
        }
    }

    //Update Behaviors Tree
    void AgentUpdate()
    {
        mTree.Tick();
    }

    //Behavior Tick Handler for Unhandling actions and decorators
    //This example handles all the action so this function won't get called
    public BehaveResult Tick(Behave.Runtime.Tree sender, bool init)
    {
        Debug.Log("Ticked Received by unhandled " +
            (BLAgentBehaveLibrary.IsAction(sender.ActiveID) ? "Action " : "Decorator ") + " ... " +
            (BLAgentBehaveLibrary.IsAction(sender.ActiveID) ? ((BLAgentBehaveLibrary.ActionType)sender.ActiveID).ToString() :
            ((BLAgentBehaveLibrary.DecoratorType)sender.ActiveID).ToString())
        );

        return BehaveResult.Success;
    }

    //Reset the tree every time an action is done
    public void Reset(Behave.Runtime.Tree sender)
    {
        //Reset the tree every time the action or decorators is done
        //Debug.Log("Resetting behavior trees");
    }

    //Behaviors of the very first priority selector
    public int SelectTopPriority(Behave.Runtime.Tree sender, params int[] IDs)
    {
        GameObject objTarget = null;

        if (health <= 0)
        {
            return IDs[2];  //Select Dead Action
        }
        else if ((IsRobotsInRange(ref objTarget)))
        {
            //print("Robots Found");
            curTargetObject = objTarget;
            return IDs[1];  //Select Attack Action to the Units
        }
        else if (IsRobotsBaseInRange())
        {
            //print("Robot base found");
            return IDs[3];  //Select Attack the base Action
        }
        else
            return IDs[0];  //Select Find the base action
    }

    //Handle Decorators
    public BehaveResult TickUnknownDecorator(Behave.Runtime.Tree sender)
    {
        //Decorator doesn't exist in this example
        return BehaveResult.Failure;
    }

    ///////////////////////////
    //Handle Actions
    ///////////////////////////
    public BehaveResult TickFindTheBaseAction(Behave.Runtime.Tree sender)
    {
        //Debug.Log("Going for the main base");
        lastActionType = BLAgentBehaveLibrary.ActionType.FindTheBase;
        animation.CrossFade("Run");

        return BehaveResult.Success;
    }

    public BehaveResult TickDieAction(Behave.Runtime.Tree sender)
    {
        //Debug.Log("Dead");
        lastActionType = BLAgentBehaveLibrary.ActionType.Die;
        Destroy(gameObject);
        return BehaveResult.Success;
    }

    //Find the air units first and attack it first
    public BehaveResult TickAttackAirUnitAction(Behave.Runtime.Tree sender)
    {
        //Debug.Log("Attacking Air Unit");
        lastActionType = BLAgentBehaveLibrary.ActionType.AttackAirUnit;
        return BehaveResult.Failure;
    }

    public BehaveResult TickAttackLandUnitAction(Behave.Runtime.Tree sender)
    {
        //Debug.Log("Attacking Land Unit");
        lastActionType = BLAgentBehaveLibrary.ActionType.AttackLandUnit;
        animation.CrossFade("Attack");
        return BehaveResult.Success;
    }

    //Lastly attack the base
    public BehaveResult TickAttackTheBaseAction(Behave.Runtime.Tree sender)
    {
        lastActionType = BLAgentBehaveLibrary.ActionType.AttackTheBase;
        animation.CrossFade("Attack");
        return BehaveResult.Success;
    }
}