﻿using UnityEngine;
using System.Collections;

public enum UnitType
{
    Robot,
    Alien,
}

public class AgentAI : MonoBehaviour
{
    public UnitType type;
    protected Transform AlienBase, RobotBase;
    protected BLAgentBehaveLibrary.ActionType lastActionType;
    protected float moveSpeed;
    protected int health = 100;
    protected float attackRange, damage;
    protected float attackRate, elapsedAttackRate;
    protected bool bDead = false;
    protected GameObject curTargetObject;

    protected virtual IEnumerator Initialise() { yield return new WaitForSeconds(1.0f); }
    
    void Start()
    {
        AlienBase = GameObject.Find("Alien_Building").transform;
        RobotBase = GameObject.Find("Robot_Building").transform;

        StartCoroutine(Initialise());
    }

    //Check Enemies in Range
    protected GameObject IsAliensInRange(ref GameObject objTarget)
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position + new Vector3(0.0f, 0.5f, 0.0f), transform.forward, out hit, attackRange))
        {
            objTarget = hit.collider.gameObject;
            return hit.collider.gameObject;
        }

        return null;
    }

    protected bool IsAliensBaseInRange()
    {
        return (Vector3.Distance(AlienBase.position, transform.position) < attackRange);
    }

    protected bool IsRobotsInRange(ref GameObject objTarget)
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position + new Vector3(0.0f, 0.5f, 0.0f), transform.forward, out hit, attackRange))
        {
            //print("Robot found in range");
            objTarget = hit.collider.gameObject;
            if(objTarget.tag == "Robot")
                return hit.collider.gameObject;
        }
        return false;
    }

    //Check whether the robot main base is in the attack range
    protected bool IsRobotsBaseInRange()
    {
        return (Vector3.Distance(RobotBase.position, transform.position) < attackRange);
    }

    private void ApplyDamage(int damage)
    {
        health -= damage;
    }
}